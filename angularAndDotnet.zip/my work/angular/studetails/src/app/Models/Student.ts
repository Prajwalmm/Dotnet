export class Student{
    Id :number;
    Name :string;
    Dept :string;
    PhNo : number;
}